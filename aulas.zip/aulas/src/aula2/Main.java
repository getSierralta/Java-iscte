package aula2;

import aula6.Person;

public class Main {

    public static void main(String[] args) {
        int a = (int) (Math.random() * 100);
        int b = (int) (Math.random() * 100);
        int c = (int) (Math.random() * 100);
        double soma = Exercicios2.somaDecimais(a,b);
        double quadrado = Exercicios2.quadradoDecimais(a);
        double diferencia = Exercicios2.diferencaDecimais(a,b);
        double mediaAritmetica = Exercicios2.mediaAritmeticaDecimais(a,b);
        double mediaGeometrica = Exercicios2.mediaGeometricaDecimais(a,b);
        double mediaHarmonica = Exercicios2.mediaHarmônicaDecimais(a,b);
        double mediaQuadratica = Exercicios2.mediaQuadraticaDecimais(a,b);
        double celciusFarenheit = Exercicios2.celciusAFarenheitDecimais(a);
        double celciusKelvin = Exercicios2.celciusAKelvinDecimais(a);
        double centimetrosPolegadas = Exercicios2.centimetrosAPolegadasDecimais(a);
        double ivaNormal = Exercicios2.ivaNormalDecimais(a);
        double ivaIntermedia = Exercicios2.ivaIntermediaDecimais(a);
        double ivaReduzida = Exercicios2.ivaReduzidaDecimais(a);
        double perimetroCirculo = Exercicios2.perimetroCirculoDecimais(a);
        double areaRetangulo = Exercicios2.areaRetanguloDecimais(a,b);
        double areaPrismaretangulo = Exercicios2.areaPrismaRetangularDecimais(a,b,c);

        System.out.println("\nNumeros a testar. A: "+a+", B: "+b+" e C:"+c+". C só utilizado no calculo da área do Prisma Retangulo.\n");
        System.out.println("A Soma dos numeros a testar é: "+ soma + ", aproximadamente: "+Exercicios2.arredondar(soma)+".\n");
        System.out.println("O Quadrado do numero a testar é: " + quadrado + ", aproximadamente: "+Exercicios2.arredondar(quadrado)+".\n");
        System.out.println("A Diferencia dos numeros a testar é: " +diferencia+ ", aproximadamente: "+Exercicios2.arredondar(diferencia)+".\n");
        System.out.println("A Média Aritmetica dos numeros a testar é: "+ mediaAritmetica + ", aproximadamente: "+Exercicios2.arredondar(mediaAritmetica)+".\n");
        System.out.println("A Média Géometrica dos numeros a testar é: "+ mediaGeometrica + ", aproximadamente: "+Exercicios2.arredondar(mediaGeometrica)+".\n");
        System.out.println("A Média Harmônica dos numeros a testar é: "+ mediaHarmonica + ", aproximadamente: "+Exercicios2.arredondar(mediaHarmonica)+".\n");
        System.out.println("A Média Quadrática dos numeros a testar é: "+ mediaQuadratica + ", aproximadamente: "+Exercicios2.arredondar(mediaQuadratica)+".\n");
        System.out.println("A converção do numero a testar  de Celcius Cº a Farenheit Fº é: "+celciusFarenheit + ", aproximadamente: "+Exercicios2.arredondar(celciusFarenheit)+".\n");
        System.out.println("A converção do numero a testar de Celcius Cº a Kelvin Kº é: " + celciusKelvin+", aproximadamente: "+Exercicios2.arredondar(celciusKelvin)+".\n");
        System.out.println("A converção do numero a testar de Centimetros a Polegadas é: " +centimetrosPolegadas+ ", aproximadamente: "+Exercicios2.arredondar(centimetrosPolegadas)+".\n");
        System.out.println("O preço com iva normal de "+ a +" é "+a+ivaNormal+", aproximadamente: "+Exercicios2.arredondar((a+ivaNormal))+".\n");
        System.out.println("O preço com iva intermedio de "+ a +" é "+a+ivaIntermedia+", aproximadamente: "+Exercicios2.arredondar((a+ivaIntermedia))+".\n");
        System.out.println("O preço com iva reduzido de "+ a +" é "+a+ivaReduzida+", aproximadamente: "+Exercicios2.arredondar((a+ivaReduzida))+".\n");
        System.out.println("O perimetro de um circulo com o raio "+a+" é: "+perimetroCirculo+", aproximadamente: " + Exercicios2.arredondar(perimetroCirculo)+".\n");
        System.out.println("A Área do Retangulo dos numeros a testar é: "+areaRetangulo + ", aproximadamente: "+Exercicios2.arredondar(areaRetangulo)+".\n");
        System.out.println("A Área do Prisma Retangulo dos numeros a testar é: "+areaPrismaretangulo + ", aproximadamente: "+Exercicios2.arredondar(areaPrismaretangulo)+".\n");

    }
}
