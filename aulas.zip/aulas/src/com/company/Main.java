package com.company;

import aula6.Person;

public class Main {

    public static void main(String[] args) {


    }
}
