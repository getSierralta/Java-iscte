package aula1;

public class Exercicios1 {
    public static void main(String[] arg){

        System.out.println("Hello World!");
    }
}
