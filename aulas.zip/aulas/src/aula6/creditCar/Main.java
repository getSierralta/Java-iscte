package aula6.creditCar;

public class Main {

    public static void main(String[] args) {
        CreditCard creditCard = new CreditCard("José Martinez","5289 0076 2414 4123","12/21", 273, 2500);
        System.out.println(creditCard);
        creditCard.gastar(300,"300$ Nintendo switch");
        creditCard.pagarCredito(200);
        creditCard.gastar(6,"6$ Pasteis de nata Belem");
        creditCard.gastar(900,"900$ Frigorifico Worthen");
        System.out.println(creditCard.getsaldo());
        creditCard.pagarCredito(1500);
        creditCard.getHistorico();
        System.out.println(creditCard.getTalao());
        creditCard.gastar(2600,"2600$ Carro fiat 5000");
    }
}
