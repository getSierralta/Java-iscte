package aula6.creditCar;

import java.util.ArrayList;

public class CreditCard {
    //Implemente a classe CreditCard cujas instâncias deverão ter um comportamento
    //semelhante ao do conhecido cartão. Cada instância da classe CreditCard deverá possuir,
    //ao ser criada, um titular, um número de 12 dígitos, um mês e ano de validade e um valor
    //máximo de débito autorizado. Deve também guardar o montante despendido até ao
    //momento e um histórico dos movimentos realizados. Por questões de simplicidade,
    //considere que um movimento é uma String com o valor e uma descrição (ex: “30EUR -
    //Bilhete de futebol”).



    private String titular;
    private String numero;
    private String validade;
    private int safeCode;
    private double valorMaximo;
    private double montanteDespendido;
    ArrayList<String> historico = new ArrayList<>(1);

    public CreditCard(String titular, String numero, String validade, int safeCode, double valorMaximo) {
        this.titular = titular;
        this.numero = numero;
        this.validade = validade;
        this.safeCode = safeCode;
        this.valorMaximo = valorMaximo;
    }

    public String getTitular() {
        return titular;
    }


    public String getNumero() {
        return numero;
    }

    public String getValidade() {
        return validade;
    }

    public double getValorMaximo() {
        return valorMaximo;
    }

    public void setValorMaximo(double valorMaximo) {
        addHistorico("O valor maximo do cartao foi subido até: "+valorMaximo+"!");
        this.valorMaximo = valorMaximo;
    }

    public double getMontanteDespendido() {
        return montanteDespendido;
    }


    //e. String getMovimentos() - devolver a lista de movimentos efetuados sob a forma
    //de uma String
    public void getHistorico() {
        System.out.println("Historico do cartão "+numero+":\n");
        for (String historia: historico) {
            System.out.println(historia);
        }
        System.out.println("************************* fim historico *************************");
    }

    public void addHistorico(String historia) {
        System.out.println(historia);
        historico.add(historia);
    }

    //a. int saldo() - devolver o saldo do cartão (diferença entre o montante gasto e o
    //limite de endividamento)
    public double getsaldo(){
        return valorMaximo-montanteDespendido;
    }

    //b. void pagarCredito(int pag) - efetuar um pagamento, isto é, abater o valor pag
    //ao montante em dívida
    public void pagarCredito(double pagamento){
        if (getsaldo() - pagamento > 0 ){
            this.montanteDespendido -= pagamento;
            addHistorico("Foi pagado: "+pagamento+".");
            System.out.println(getsaldo());
        }else{
            addHistorico("O pagamento ultrapassou a divida, foi pagado: "+(pagamento-this.montanteDespendido)+".");
            this.montanteDespendido = 0;
            System.out.println(getsaldo());
        }

    }

    //c. void gastar(int quantia, String descr) - registar um movimento e atualizar o
    //montante gasto
    public void gastar(int quantia, String descr){
        if (montanteDespendido + quantia <= valorMaximo){
            addHistorico(descr);
            this.montanteDespendido += quantia;
        }else {
            addHistorico("Error na compra "+descr+" saldo insuficiente.");
        }

    }

    //d. String obterTalao() - devolver a String que corresponde ao último movimento
    //realizado
    public String getTalao(){
        return historico.get(historico.size()-1);
    }

    @Override
    public String toString() {
        return "CreditCard {" +
                "titular = '" + titular + '\'' +
                ", numero = '" + numero + '\'' +
                ", validade = '" + validade + '\'' +
                ", valorMaximo = " + valorMaximo +
                '}';
    }
}
