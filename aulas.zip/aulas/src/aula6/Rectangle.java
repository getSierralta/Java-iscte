package aula6;

public class Rectangle {
    //Desenvolva uma classe para representar retângulos, tendo em conta a sua largura e comprimento.
    //Os objetos retângulo deverão ser imutáveis, isto é, uma vez criado as suas dimensões não podem
    //ser alteradas.
    //○ Implemente o construtor e métodos que permitem obter o comprimento e a largura do retângulo
    //○ Defina um método construtor adicional que cria um quadrado.
    //○ Defina as funções que permitem obter as seguintes informações:
    //■ área
    //■ perímetro
    //■ comprimento da diagonal
    //■ se o retângulo é um quadrado


    // atributos
    private final double base;
    private final double height;
    private final double area;
    private final double perimeter;
    private final double diagonal;
    private final boolean square;
    // constructor
    public Rectangle(double base, double height){
        this.base = base;
        this.height = height;
        this.area = getArea();
        this.perimeter = getPerimeter();
        this.diagonal = getDiagonal();
        this.square = getSquare();

    }
    public Rectangle(double base){
        this.base= base;
        this.height = base;
        this.area = getArea();
        this.perimeter = getPerimeter();
        this.diagonal = getDiagonal();
        this.square = getSquare();
    }
    //methods
    public double getBase(){
        return base;
    }
    public double getHeight(){
        return height;
    }
    public double getArea(){
        double area = this.base * this.height;
        return area;
    }
    public double getPerimeter(){
        double perimeter = this.base*2 + this.height*2;
        return perimeter;
    }
    public  double getDiagonal(){
        double diagonal = Math.sqrt(this.base*this.base + this.height*this.height);
        return diagonal;
    }
    public boolean getSquare(){
        boolean square;
        if(this.base == this.height){
            square = true;
        }else{
            square = false;
        }
        return square;
    }
    @Override
    public String toString(){
        String atributos = "Base: "+base+"\n";
        atributos = atributos + "Height: "+height+"\n";
        atributos = atributos + "Area: "+area+"\n";
        atributos = atributos + "Perimeter: "+perimeter+"\n";
        atributos = atributos + "Diagonal: "+diagonal+"\n";
        atributos = atributos + "Is it a square? : "+square+"\n";
        return atributos;
    }
}
