package aula6.playlist;

public class Song {
    // A cada música está associado o título e a duração da mesma

    private String title;
    private String artist;
    private int longS;

    public Song(String title, String artist, int longS){
        this.title = title;
        this.artist = artist;
        this.longS = longS;

    }
    public String getTitle(){
        return this.title;
    }
    public int getLongS(){
        return longS;
    }
    @Override
    public String toString(){
        int minutes = (int) (longS/60);
        int seconds = (int) (longS%60);
        return "Title: "+title+" - "+artist+".\nLong: "+minutes+":"+seconds;
    }
}
