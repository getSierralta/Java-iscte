package aula6.playlist;

public class Playlist {
    //A playlist guarda uma lista de
    //músicas e deverá permitir as seguintes operações:
    //a. mostrar a lista de músicas atualmente na playlist
    //b. acrescentar ou retirar músicas à playlist
    //c. calcular a duração total de todas as músicas contidas na playlist
    private String name;
    private Song[] songs;


    public Playlist(Song[] songs,String name){
        this.name = name;
        this.songs = replaceSongs(songs);

    }
    public Song[] replaceSongs(Song[] songs){
        this.songs = new Song[songs.length];
        for (int i = 0; i< this.songs.length; i++){
            this.songs[i] = songs[i];
        }
        return this.songs;
    }
    public void getSongs(){
        System.out.println("The songs inside the play list are: ");
        for (int i = 0; i < songs.length; i++){
            if (checkIsNull(songs[i])){
                System.out.println((i+1)+".- Null");
            }else {
                System.out.println((i+1)+".- "+songs[i].toString());
            }


        }
    }
    public boolean checkIsNull(Song song) {
            if (song == null) {
                return true;
            }
        return false;
    }

    public void addSong(Song song){
            Song[] copy = new Song[songs.length+1];
            int i;
            for (i = 0; i < this.songs.length; i++){
                copy[i] = songs[i];
            }
            copy[i] = song;
            replaceSongs(copy);
            System.out.println("Song "+this.songs[i].getTitle()+" was added to the playlist "+name+" succesfully!");
    }
    public void deleteSong(Song song){
        int l = songs.length;
        Song[] copy = new Song[l-1];
        int i = 0;
        for (i = 0; i < copy.length; i++){
            if(songs[i].getTitle() != song.getTitle()){
                copy[i] = songs[i];
            }else{
                break;
            }
        }
        i++;
        for (; i <= copy.length; i++){
            copy[i-1] = songs[i];
        }
        replaceSongs(copy);
        System.out.println("Song "+song.getTitle()+" was removed from the playlist "+name+" succesfully!");

    }

    public String sumOfSongsLong(){
        int sum = 0;
        for (int i = 0; i < songs.length; i++){
            sum = sum + songs[i].getLongS();
        }

        int minutes = (int) (sum/60);
        int seconds = (int) (sum%60);

        return minutes+":"+seconds;
    }

}
