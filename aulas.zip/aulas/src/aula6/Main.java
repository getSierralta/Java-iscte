package aula6;

public class Main {

    public static void main(String[] args) {
        Person primeira = new Person("Maria","Silva",28);

        primeira.setNationality("Portuguesa");
        System.out.println(primeira.getNationality());
        System.out.println(primeira.toString());

        System.out.println(" ");
        Rectangle quadrado = new Rectangle(4);
        System.out.println(quadrado.toString());
        Rectangle segundo = new Rectangle(5,12);
        System.out.println(segundo.toString());
    }
}
