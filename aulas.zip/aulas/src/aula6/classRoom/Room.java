package aula6.classRoom;

public class Room {
    //Cada sala tem a sua capacidade, o nome do bloco (ex: A, B, C, D) e o número da sala.
    private char blockName;
    private int number;
    private int capacity;
    private Student[] students;

    public Room(char blockName, int capacity, int number, Student[] students){
        this.blockName = blockName;
        this.capacity = capacity;
        this.number = number;
        this.students = setStudents(students);

    }

    public char getBlockName(){
        return blockName;
    }
    public int getCapacity(){
        return capacity;
    }
    public int getNumber(){
        return number;
    }

    public Student[] setStudents(Student[] students){
        if (students.length > capacity){
            System.out.println("Error, the students overflow the capacity of the class room "+blockName+number+"!");
        }else{
            this.students = new Student[this.capacity];
            int i = 0;
            for (int j = students.length; j > capacity; j--) {
                this.students[i] = students[i];
                i++;
            }
            for (int k = students.length; k < capacity; k++){
                this.students[k] = null;
            }
            System.out.println("Students added to the class room "+blockName+number+"!");
        }
        return students;
    }

    public void printStudents(){

        for(int i = 0; i < students.length; i++){
            if(students[i] == null){
                System.out.println("Free space \n");
            }else{
                System.out.print(students[i].toString()+"\n\n");
            }


        }
    }

    public void deleteStudent(int studentNumber){
        for (int i = 0; i < capacity; i++){
            if(studentNumber == students[i].getNumber()){
                System.out.println("Student " + this.students[i].getName()+" was removed from the room "+blockName+number+" succesfully!");
                students[i].setClass('0',0);
                students[i] = null;
                break;
            }
        }
    }
    public void addStudent(Student student){
        for (int i = 0; i < students.length; i++){
            if(this.students[i] == null){
                this.students[i] = student;
                students[i].setClass(blockName,number);
                System.out.println("Student "+this.students[i].getName()+" was added to the room "+blockName+number+" succesfully!");
                break;
            }
        }
    }

    @Override
    public String toString(){
        return "Name: "+blockName+"\nCapacity: "+capacity+"\nClass number: "+number;
    }
}
