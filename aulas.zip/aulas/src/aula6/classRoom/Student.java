package aula6.classRoom;

public class Student {
    //Cada aluno terá o número de aluno, o nome e o curso.
    private int number;
    private String name;
    private int classNumber;
    private char blockName;


    public Student(int number, String name){
        this.number = number;
        this.name = name;

    }
    public String getName(){
        return this.name;
    }
    public char getBlockName(){
        return this.blockName;
    }
    public int getNumber(){
        return this.number;
    }
    public void setClass(char blockName,int classNumber){
        this.blockName = blockName;
        this.classNumber = classNumber;
    }

    @Override
    public String toString(){
        return "Name: "+name+"\nClass name: "+blockName+classNumber+"\nNumber: "+number;
    }
}
