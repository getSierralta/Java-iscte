package aula6.calculator;


public abstract class Calculator {
    //Implemente a classe Calculator. O objeto calculadora deve ser capaz de realizar os
    //cálculos matemáticos comuns de uma calculadora normal:
    //a. Soma
    //b. Subtração
    //c. Multiplicação
    //d. Divisão
    //e. Potência
    //f. Resto da divisão
    //g. Fórmula resolvente
    //h. A calculadora possui ainda um história das operações realizadas, armazenadas
    //em formato String num vetor. Desenvolva as funções necessárias para:
    //i. guardar o histórico no vetor
    //ii. obter o histórico completo
    //iii. obter as últimas operações realizadas pela calculadora (histórico
    //parcial)

    private String[] historic;

    public Calculator(){
        historic = new String[1];
        historic[0] = "\nHistoric of the calculator: ";
    }

    public double sum(double a,double b){
        double result = a+b;
        addToHistoric("Sum: "+a+" + "+b+" = "+result);
        return result;
    }

    protected abstract void addToHistoric(String s);

    public double subtraction(double a,double b){
        double result = a-b;
        addToHistoric("Subtraction: "+a+" - "+b+" = "+result);
        return result;
    }
    public double division(double a,double b){
        double result = a/b;
        addToHistoric("Division: "+a+" / "+b+" = "+result);
        return result;
    }
    public double multiplication(double a,double b){
        double result = a*b;
        addToHistoric("Division: "+a+" * "+b+" = "+result);
        return result;
    }
    
}
