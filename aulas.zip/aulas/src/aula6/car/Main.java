package aula6.car;

import aula6.Person;
import aula6.Rectangle;

import java.util.concurrent.TimeUnit;

public class Main {

    public static void main(String[] args) {
        Person primeira = new Person("Maria","Silva",28);
        Car beetle = new Car("Volkswagen","Beetle",4,9.45, 54.9);
        beetle.registerCar(22,10,2020,"AA-01-AA",primeira);
        Thread thread1 = new Thread(){
            @Override
            public void run(){
                System.out.println(beetle.getRegistration());
                beetle.run(10);
                System.out.println(beetle.fillGas(10));
                beetle.run(5);
                System.out.println(beetle.fillGas(55));
                beetle.run(3);
                beetle.run(5);
            }
        };

        Thread thread2 = new Thread(){
            @Override
            public void run(){
                System.out.println(beetle.isRunning());
                try {
                    System.out.println(beetle.isRunning());
                    TimeUnit.SECONDS.sleep( 2);
                    System.out.println(beetle.isRunning());
                    TimeUnit.SECONDS.sleep( 7);
                    System.out.println(beetle.isRunning());
                    TimeUnit.SECONDS.sleep( 3);
                    System.out.println(beetle.isRunning());
                    TimeUnit.SECONDS.sleep( 5);
                    System.out.println(beetle.isRunning());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };

        thread1.start();
        thread2.start();
    }
}
