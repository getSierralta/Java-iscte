package aula6.car;

import aula6.Person;

import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.concurrent.TimeUnit;

public class Car {
    //Implemente a classe Car. Um carro possui algumas propriedades e caraterísticas que
    //variam de modelo para modelo, tais como a marca, o modelo, o número de lugares, a
    //matrícula, o mês e ano de registo, o consumo em 100km, etc… Certos atributos devem
    //ser indicados aquando a criação do carro.
    //Deve criar os testes que achar necessário para testar as funções desenvolvidas.
    //a. Desenvolva os getters e os setters dos atributos que lhe pareçam adequados.
    //b. O carro possui um tanque de combustível, com uma capacidade atual e uma
    //capacidade máxima. Implemente a função encherDeposito() que simula o
    //abastecimento.
    //c. A função run() deve simular o percurso feito pelo automóvel em 1 km. O
    //combustível associado a este percurso deve ser descontado na capacidade atual
    //do tanque.
    //d. Deve ser possível determinar se o carro se encontra em funcionamento.
    //Implemente a função isLigado() e outras que considera necessárias.
    //e. O automóvel possui um proprietário, que é representado pela classe Person
    //(desenvolvida na aula). Crie as funções e atributos necessários que permitem o
    //registo do proprietário à viatura.
    //f. Implemente a função toString() que deve devolver a informação que achar
    //adequada.
    private final String maker;
    private final String model;
    private final int sits;
    private String registration;
    private int monthOfRegistration;
    private int dayOfRegistration;
    private int yearOfRegistraion;
    private final double consumptionPerK;
    private double gasTankStatus;
    private final double gasTank;
    private boolean flag;
    private Person owner;



    public Car(String maker,String model, int sits,double consumption100Km, double gasTank){
        this.maker = maker;
        this.model = model;
        this.sits = sits;
        this.consumptionPerK = (consumption100Km/100);
        this.gasTank = gasTank;

    }
    public String getMaker(){
        return maker;
    }
    public String getModel(){
        return model;
    }
    public int getSits(){
        return sits;
    }
    public String getRegistration(){
        return  "\nRegistration: " +registration+
                "\nRegistrated by: "+owner.getLastName()+" "+owner.getFirstName()+"."+
                "\nOn the "+dayOfRegistration+", "+monthOfRegistration+" of "+yearOfRegistraion+".\n";
    }
    public String getDateRegistration(){
        return dayOfRegistration+", "+monthOfRegistration+" of "+yearOfRegistraion;
    }
    public double getConsumption100Km(){
        return consumptionPerK*100;
    }
    public String getGasTankStatus(){
        NumberFormat format = NumberFormat.getInstance();
        format.setRoundingMode(RoundingMode.DOWN);
        format.setMaximumFractionDigits(2);
        return format.format(gasTankStatus);
    }
    public void registerCar(int day, int month, int year, String registration, Person person){
        this.dayOfRegistration = day;
        this.monthOfRegistration = month;
        this.yearOfRegistraion = year;
        this.registration = registration;
        this.owner = person;

    }

    public String fillGas(double liters){
        if (gasTankStatus + liters <= gasTank){
            gasTankStatus = gasTankStatus + liters;
            return "Gas status: " + getGasTankStatus();
        }else{
            this.gasTankStatus = this.gasTank;
            return "Gas tank overflow."+"\nGas status: "+getGasTankStatus();
        }

    }

    public void run(double kilometers) {
        for(int i = 0; i <= kilometers; i++){
            if (gasTankStatus > 0){
                System.out.println("Running......");
                try {
                    TimeUnit.SECONDS.sleep( 1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                this.gasTankStatus = gasTankStatus - consumptionPerK;
                this.flag = true;
            }else{
                System.out.println("Not enough gas!");
                break;
            }
        }
        this.flag = false;
        System.out.println("Stopped.");

    }
    public String isRunning(){
        if (flag){
            return "The car is running.";
        }
        return "The car is not running.";
    }

    @Override
    public String toString() {
        return owner+"'s car {" +
                "maker ='" + maker + '\'' +
                ", model ='" + model + '\'' +
                ", sits =" + sits +
                ", consumption100Km =" + consumptionPerK*100 +
                "}";
    }
}
