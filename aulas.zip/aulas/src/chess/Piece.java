package chess;




public abstract class Piece {

    // We made an abstract class piece, that way we don't have to repeat the same for each different piece
    // And just focus on their individuality
    private Position pos;
    private final String color;
    private String name;
    private String code;


    public Piece(int pos_x, int pos_y, String color, String name,String code){
        this.pos = new Position(pos_x,pos_y);
        this.color = color;
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }
    public String getCode() {
        return code;
    }

    public Position getPos(){
        return pos;
    }

    public String getColor(){
        return color;
    }

    public abstract Position[] getMovements();

    public void setName(String name) {
        this.name = name;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public boolean isFreeSpace( Piece piece){
        return piece.getColor().equals("null");
    }
    public boolean canEat( Piece piece){
       if(this.getColor().equals("White" )  && piece.getColor().equals("Black")){
            return true;
        }else return this.getColor().equals("Black") && piece.getColor().equals("White");
    }
    public abstract Piece copy();

    public void setPos(int x, int y) {
        this.pos = new Position(x, y);
    }
    public String toString2(Layout table){
        Piece[][] layout = table.getLayoutCopy();
        Position[] positions = getMovements();
        for (Position position : positions) {
            int x = position.getX();
            int y = position.getY();
            if (canEat(layout[y][x])) {
                layout[y][x].setCode("   !  ");
            } else if (!isFreeSpace(layout[y][x])) {
                break;
            } else {
                layout[y][x] = this;
            }
        }
        StringBuilder statement = new StringBuilder();
        for (Piece[] pieces : layout) {
            for (int j = 0; j < layout.length; j++) {
                statement.append(pieces[j].getCode());
            }
            statement.append("\n");
        }
        return statement.toString();
    }

    @Override
    public String toString() {
        return "Piece {" +
                "pos = " + pos +
                ", color = '" + color + '\'' +
                ", name = '" + name + '\'' +
                ", code = '" + code + '\'' +
                '}';
    }


}
