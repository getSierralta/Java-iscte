package chess;

import java.util.ArrayList;

public class King extends Piece{
    //The king moves one square in any direction. The king also has a special move called castling that involves also moving a rook.
    //[y+1,x], [y+1,x+1], [y,x-1], [y-1,x-1], [y-1], [y-1,x+1], [y,x+1], [y+1,x+1]


    public King(int pos_x, int pos_y, String color, String name, String code) {
        super(pos_x, pos_y, color, name, code);
    }
    @Override
    public Piece copy() {
        King pieceCopy = new King(getPos().getX(),getPos().getY(),getColor(),getName(),getCode());
        return pieceCopy;
    }

    @Override
    public Position[] getMovements() {
        int x = super.getPos().getX();
        int y = super.getPos().getY();
        ArrayList<Position> pos = new ArrayList<>();
        pos.add(new Position(x,y));
        for (int i = 0; i < 7; i++) {
            if (x + 1 < 7 && x + 1 > 0 && y + 1 < 7 && y + 1 > 0){
                pos.add(new Position(x+1,y+1));
            }
            if (x - 1 < 7 && x - 1 > 0 && y - 1 < 7 && y - 1 > 0){
                pos.add(new Position(x-1,y-1));
            }
            if (x - 1 < 7 && x - 1 > 0 && y + 1 < 7 && y + 1 > 0){
                pos.add(new Position(x-1,y+1));
            }
            if (x + 1 < 7 && x + 1 > 0 && y - 1 < 7 && y - 1 > 0){
                pos.add(new Position(x+1,y-1));
            }
            if (x + 1 < 7 && x + 1 > 0){
                pos.add(new Position(x+1,y));
            }
            if (x - 1 < 7 && x - 1 > 0){
                pos.add(new Position(x-1,y));
            }
            if (y + 1 < 7 && y + 1 > 0){
                pos.add(new Position(x,y+1));
            }
            if (y - 1 < 7 && y - 1 > 0){
                pos.add(new Position(x,y-1));
            }

        }

        Position[] positions = new Position[pos.size()];
        positions = pos.toArray(positions);
        return  positions;
    }
}
