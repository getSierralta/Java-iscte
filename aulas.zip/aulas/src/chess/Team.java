package chess;

import java.util.ArrayList;

public class Team {
    private final String name;
    private final ArrayList<Piece> piecesEaten = new ArrayList<>(1);

    public Team(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Piece> getPiecesEaten() {
        return piecesEaten;
    }

    public void addPiece(Piece piece) {
        piecesEaten.add(piece);
    }

    @Override
    public String toString() {
        StringBuilder pieces = new StringBuilder("Team: " + this.getName());
        for (Piece piece : piecesEaten) {
            pieces.append(" | ").append(piece.getName());
        }
        pieces.append(" | ");
        return pieces.toString();
    }
}
