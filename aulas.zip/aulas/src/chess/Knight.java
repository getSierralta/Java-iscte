package chess;


import java.util.ArrayList;

public class Knight extends Piece{
    //A knight moves to any of the closest squares that are not on the same rank, file, or diagonal.
    // (Thus the move forms an "L"-shape: two squares vertically and one square horizontally, or two squares horizontally and one square vertically.)
    // The knight is the only piece that can leap over other pieces.
    //[y+2,x-1],[y+1,x-2],[y-1,x-2],[y-2,x-1],[y-2,x+1],[y-1,x-2],[y+1,x+2],[y+2,x+1]


    public Knight(int pos_x, int pos_y, String color, String name, String code) {
        super(pos_x, pos_y, color, name, code);
    }

    @Override
    public Piece copy() {
        Knight pieceCopy = new Knight(getPos().getX(),getPos().getY(),getColor(),getName(),getCode());
        return pieceCopy;
    }


    @Override
    public Position[] getMovements() {
        //Code made by Joao Paulo
        int actualX = getPos().getX();
        int actualY = getPos().getY();
        ArrayList<Position> pos = new ArrayList<>();
        pos.add(new Position(actualX,actualY));
        for (int x = -2; x <= 2; x++)
            for (int y = -2; y <= 2; y++) {
                if ((Math.abs(x) + Math.abs(y)) != 3) //not an "L" move
                    continue;
                if (actualX + x > 7 || actualX + x < 0 ||
                        actualY + y > 7 || actualY + y < 0) //out of bounds
                    continue;
               pos.add(new Position(actualX + x, actualY + y));
            }
        Position[] positions = new Position[pos.size()];
        positions = pos.toArray(positions);
        return  positions;
    }

    @Override
    public String toString2(Layout table) {
        Piece[][] layout = table.getLayoutCopy();
        Position[] positions = getMovements();
        for (Position position : positions) {
            int x = position.getX();
            int y = position.getY();
            if (canEat(layout[y][x])) {
                layout[y][x].setCode("|!!!|");
            } else if (isFreeSpace(layout[y][x])) {
                layout[y][x] = this;
            }
        }

        StringBuilder statement = new StringBuilder();
        for (Piece[] pieces : layout) {
            for (int j = 0; j < layout.length; j++) {
                statement.append(pieces[j].getCode());
            }
            statement.append("\n");
        }
        return statement.toString();
    }
}
