package chess;


import java.util.ArrayList;

public class Pawn extends Piece{
    //A pawn can move forward to the unoccupied square immediately in front of it on the same file,
    // or on its first move it can advance two squares along the same file, provided both squares are unoccupied
    // (black dots in the diagram); or the pawn can capture an opponent's piece on a square diagonally in front of
    // it on an adjacent file, by moving to that square.
    // A pawn has two special moves: the en passant capture and promotion.
    //[y+2,x],[y+1,x][y+1,x-1][y+1,x+1]


    public Pawn(int pos_x, int pos_y, String color, String name, String code) {
        super(pos_x, pos_y, color, name, code);
    }
    @Override
    public Piece copy() {
        Pawn pieceCopy = new Pawn(getPos().getX(),getPos().getY(),getColor(),getName(),getCode());
        return pieceCopy;
    }
    /**
    public Piece promotion(Piece piece){
        String name = piece.getName();
        String color = this.getColor();
        String code = "P";
        if (color.equals("Black")){
            code = "B";
        }else if (color.equals("White")){
            code = "W";
        }
        return switch (name) {
            case "Queen" -> new Queen(this.getPos().getX(), this.getPos().getY(), this.getColor(), color + " Queen*", "Q" + code);
            case "Rook" -> new Rook(this.getPos().getX(), this.getPos().getY(), this.getColor(), color + " Rook*", "R" + code);
            case "Bishop" -> new Bishop(this.getPos().getX(), this.getPos().getY(), this.getColor(), color + " Bishop*", "Q" + code);
            case "Knight" -> new Knight(this.getPos().getX(), this.getPos().getY(), this.getColor(), color + " Knight*", "Q" + code);
            default -> throw new IllegalStateException("Unexpected value: " + piece.getName());
        };
    }**/
    @Override
    public Position[] getMovements(){
        int x = super.getPos().getX();
        int y = super.getPos().getY();
        ArrayList<Position> pos = new ArrayList<>();
        pos.add(new Position(x,y));
            if (super.getColor().equals("White") && y - 1 > 0 && y - 1 < 7) {
                pos.add(new Position( x,y - 1));
                if (super.getPos().getY() == 6) {
                    pos.add(new Position( x,4));
                }
            } else if(super.getColor().equals("Black") && y + 1 < 7 && y + 1 > 0){
                pos.add(new Position(x, y + 1));
                if (super.getPos().getY() == 1) {
                    pos.add(new Position(x, 3));
                }
            }


        Position[] positions = new Position[pos.size()];
        positions = pos.toArray(positions);
        return  positions;
    }

    @Override
    public String toString2(Layout table) {
        Piece[][] layout = table.getLayoutCopy();
        Position[] positions = getMovements();
        for (Position position : positions) {
            int x = position.getX();
            int y = position.getY();
            if (this.getColor().equals("Black") ) {
                if (isFreeSpace(layout[y][x])) {
                    layout[y][x] = this;
                }
                if (x + 1 < 7 && y + 1 < 7) {
                    if (canEat(layout[y + 1][x + 1])) {
                        layout[y + 1][x + 1].setCode("|!!!|");
                    }
                } else if (x - 1 < 7 && x - 1 > 0 && y + 1 < 7) {
                    if (canEat(layout[y + 1][x - 1])) {
                        layout[y + 1][x - 1].setCode("|!!!|");
                    }
                }
            }
            if (this.getColor().equals("White")) {
                if (isFreeSpace(layout[y][x])) {
                    layout[y][x] = this;
                }
                if (x + 1 < 7 && y - 1 > 0 && y - 1 < 7) {
                    if (canEat(layout[y - 1][x + 1])) {
                        layout[y - 1][x + 1].setCode("|!!!|");
                    } else if (isFreeSpace(layout[y][x])) {
                        layout[y][x] = this;
                    }
                } else if (x - 1 < 7 && x - 1 > 0 && y - 1 > 0 && y - 1 < 7) {
                    if (canEat(layout[y - 1][x - 1])) {
                        layout[y - 1][x + 1].setCode("|!!!|");
                    }
                }
            }
        }
        StringBuilder statement = new StringBuilder();
        for (Piece[] pieces : layout) {
            for (int j = 0; j < layout.length; j++) {
                statement.append(pieces[j].getCode());
            }
            statement.append("\n");
        }
        return statement.toString();
    }
}
