package chess;

import java.util.Scanner;

public class Main {
    public static void main (String[] args){

        Scanner keyboard = new Scanner(System.in);
       System.out.println("Welcome players, lets make the teams!"
       +"\nWhats the name of the black team?");
       Team black = new Team(keyboard.nextLine());
       System.out.println("Whats the name of the White team?");
       Team white = new Team(keyboard.nextLine());
       System.out.println("\nAlright "+black.getName()+" and "+white.getName()+" this is your board: \n");

       Layout layout = new Layout();
       System.out.println(layout);
       System.out.println("\nAs always white plays first so "+white.getName()+" this is the menu, what do you want to do? ");
       while (checkmate(white,black)){
           menu(white,black,layout);
       }



    }
    public static void menu(Team white, Team black, Layout layout){
        Scanner keyboard = new Scanner(System.in);
        System.out.println("\n|| Welcome to the menu ---------------------------"
                +"\n|| 1. See possibles movements of one piece. "
        +"\n|| 2. Move Piece."
        +"\n|| 3. Get teams statistics."
        +"\n|| 4. See table."
        +"\n|| 5. Withdraw."
        +"\n||-----------------------------------------------------");
        int key = 0;
        boolean successfulInput = false;
        while (!successfulInput){
            try {
                key = keyboard.nextInt();
                successfulInput = true;
            }catch (Exception e){
                System.out.println("Heyyy! im asking for a number D: ");
            }
        }


        switch (key) {
            case 1 -> {
                seeMovements(layout);
                break;
            }
            case 2 -> {
                movePiece(white, black, layout);
                break;
            }
            case 3 -> {
                getTeamStatistics(white, black);
                break;
            }
            case 4 -> {
                getLayout(layout);
                break;
            }
            case 5 -> {
                withdraw(white);
                break;
            }

        }

    }

    private static void getLayout(Layout layout) {
        System.out.println(layout);
    }

    private static void getTeamStatistics(Team white, Team black) {
        System.out.println("Pieces eaten by "+white.getName()+":\n");
        for (int i = 0; i < white.getPiecesEaten().size(); i++){
            System.out.print(", "+white.getPiecesEaten().get(i).getName());
        }
        System.out.println("\nPieces eaten by "+black.getName()+":\n");
        for (int i = 0; i < black.getPiecesEaten().size(); i++){
            System.out.print(", "+black.getPiecesEaten().get(i).getName());
        }

    }

    public static void seeMovements(Layout layout){
        Scanner keyboard = new Scanner(System.in);
        System.out.println("\nPlease insert the code of the piece you wish to see:");
        String code = keyboard.nextLine();
        for (int i = 0; i < layout.getLayout().length; i ++) {
            for (int j = 0; j < layout.getLayout().length; j++){
                if (layout.getLayout()[i][j].getCode().equals(code)){
                    System.out.println(layout.getLayout()[i][j].toString2(layout));
                    break;
                }
            }
        }
    }
    public static void movePiece(Team white, Team black, Layout layout){
        Scanner keyboard = new Scanner(System.in);
        System.out.println("\nPlease insert the code of the piece you wish to move:");
        String code = keyboard.nextLine();
        System.out.println("\nPlease insert the letter of the place you wish to move it:");
        String letter = keyboard.nextLine();
        int intLetter = stringToInt(letter);
        System.out.println("\nPlease insert the number of the place you wish to move it:");
        int number = keyboard.nextInt();
        int number2 = number;
        number = 8 - number;
        for (int i = 0; i < layout.getLayout().length; i ++) {//getLayout contains a Matrix so we have to make
            for (int j = 0; j < layout.getLayout().length; j++){//a loop within a loop
                if (layout.getLayout()[i][j].getCode().equals(code)){//We check if the piece they are asking for exist inside our layout
                        for (int k = 0; k < layout.getLayout()[i][j].getMovements().length; k++){//Now that we have our piece we are going
                            //To iterate our piece's movements to see if its a valid movement
                            if (layout.getLayout()[i][j].getMovements()[k].getX() == intLetter && layout.getLayout()[i][j].getMovements()[k].getY() == number){
                                //If the coordinates the person is sending are inside our pieces getMovements means is valid
                                //Then we can safely move it there
                                //But before assigning it it's place we check if we can eat something
                                if (layout.getLayout()[i][j].canEat(layout.getLayout()[number][intLetter])){
                                    if (layout.getLayout()[i][j].getColor().equals("White")){
                                        white.addPiece(layout.getLayout()[number][intLetter]);
                                        System.out.println(layout.getLayout()[i][j].getName()+" Has eaten "+ layout.getLayout()[number][intLetter]+"!");
                                    }else if(layout.getLayout()[i][j].getColor().equals("Black")){
                                        black.addPiece(layout.getLayout()[number][intLetter]);
                                        System.out.println(layout.getLayout()[i][j].getName()+" Has eaten "+ layout.getLayout()[number][intLetter].getName()+"!");
                                    }
                                }


                                Piece piece = layout.getLayout()[number][intLetter]; // We save the empty space
                                layout.getLayout()[number][intLetter] = layout.getLayout()[i][j];
                                layout.getLayout()[number][intLetter].setPos(j,i);//We designate the piece the new position
                                piece.setPos(intLetter,number);
                                layout.getLayout()[i][j] = piece; // We designate the old position an empty space

                                System.out.println(layout.getLayout()[number][intLetter].getName()+" has moved to the position "+letter.toUpperCase()+number2+"!");
                                System.out.println(layout);


                            }
                        }
                    break;
                }
            }
        }
    }
    public static int stringToInt(String x){
        return switch (x) {
            case "A", "a" -> 0;
            case "B", "b" -> 1;
            case "C", "c" -> 2;
            case "D", "d" -> 3;
            case "E", "e" -> 4;
            case "F", "f" -> 5;
            case "G", "g" -> 6;
            case "H", "h" -> 7;
            default -> 8;
        };

    }

    public static void withdraw(Team team){
        team.addPiece(new King(0,0,"null","King","  :(   "));
    }
    public static boolean checkmate(Team white, Team black){
        for (int i = 0; i < white.getPiecesEaten().size(); i++) {
            if (white.getPiecesEaten().get(i).getName().equals("King")){
                System.out.println("Black team has made Checkmate!!!!!!! end of game");
                return false;
            }
        }
        for (int i = 0; i < black.getPiecesEaten().size(); i++) {
            if (black.getPiecesEaten().get(i).getName().equals("King")){
                System.out.println("White team has made Checkmate!!!!!!! end of game");
                return false;
            }
        }
        return true;
    }

}
