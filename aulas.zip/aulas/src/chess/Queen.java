package chess;

import java.util.ArrayList;

public class Queen extends Piece{
    //A queen combines the power of a rook and bishop and
    // can move any number of squares along a rank, file, or diagonal, but cannot leap over other pieces.
    //[y+1,x], [y+1,x+1], [y,x-1], [y-1,x-1], [y-1], [y-1,x+1], [y,x+1], [y+1,x+1] till reaches a barrier


    public Queen(int pos_x, int pos_y, String color, String name, String code) {
        super(pos_x, pos_y, color, name, code);
    }
    @Override
    public Piece copy() {
        Queen pieceCopy = new Queen(getPos().getX(),getPos().getY(),getColor(),getName(),getCode());
        return pieceCopy;
    }

    @Override
    public Position[] getMovements() {
        int x = super.getPos().getX();
        int y = super.getPos().getY();
        int x1 = super.getPos().getX();
        int y1 = super.getPos().getY();
        int x2 = super.getPos().getX();
        int y2 = super.getPos().getY();
        int x3 = super.getPos().getX();
        int y3 = super.getPos().getY();
        int x4 = super.getPos().getX();
        int y4 = super.getPos().getY();
        int x5 = super.getPos().getX();
        int y5 = super.getPos().getY();
        int x6 = super.getPos().getX();
        int y6 = super.getPos().getY();
        int x7 = super.getPos().getX();
        int y7 = super.getPos().getY();
        ArrayList<Position> pos = new ArrayList<>();
        pos.add(new Position(x,y));
        for (int i = 0; i < 7; i++) {
            if (x + 1 > 7 || x + 1 < 0 || y + 1 > 7 || y + 1 < 0) //out of bounds
                continue;
            x++;y++;
            pos.add(new Position(x,y));

        }
        for (int i = 0; i < 7; i++) {
            if (x1 - 1 > 7 || x1 - 1 < 0 || y1 - 1 > 7 || y1 - 1 < 0) //out of bounds
                continue;
            x1--;y1--;
            pos.add(new Position(x1,y1));

        }
        for (int i = 0; i < 7; i++) {
            if (x2 - 1 > 7 || x2 - 1 < 0 || y2 + 1 > 7 || y2 + 1 < 0) //out of bounds
                continue;
            x2--;y2++;
            pos.add(new Position(x2,y2));

        }
        for (int i = 0; i < 7; i++) {
            if (x3 + 1 > 7 || x3 + 1 < 0 || y3 - 1 > 7 || y3 - 1 < 0) //out of bounds
                continue;
            x3++;y3--;
            pos.add(new Position(x3,y3));

        }
        for (int i = 0; i < 7; i++) {
            if (y4 + 1 > 7 || y4 + 1 < 0) //out of bounds
                continue;
            y4++;
            pos.add(new Position(x4,y4));

        }
        for (int i = 0; i < 7; i++) {
            if ( y5 - 1 > 7 || y5 - 1 < 0) //out of bounds
                continue;
            y5--;
            pos.add(new Position(x5,y5));

        }
        for (int i = 0; i < 7; i++) {
            if (x6 - 1 > 7 || x6 - 1 < 0 ) //out of bounds
                continue;
            x6--;
            pos.add(new Position(x6,y6));

        }
        for (int i = 0; i < 7; i++) {
            if (x7 + 1 > 7 || x7 + 1 < 0 ) //out of bounds
                continue;
            x7++;
            pos.add(new Position(x7,y7));

        }

        Position[] positions = new Position[pos.size()];
        positions = pos.toArray(positions);
        return  positions;
    }

}
