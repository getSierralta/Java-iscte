package chess;


public class Layout {
    Rook rookB1;
    Knight knightB1;
    Bishop bishopB1;
    Queen queenB;
    King kingB;
    Bishop bishopB2;
    Knight knightB2;
    Rook rookB2;
    Pawn pawnB1;
    Pawn pawnB2;
    Pawn pawnB3;
    Pawn pawnB4;
    Pawn pawnB5;
    Pawn pawnB6;
    Pawn pawnB7;
    Pawn pawnB8;
    Pawn pawnW1;
    Pawn pawnW2;
    Pawn pawnW3;
    Pawn pawnW4;
    Pawn pawnW5;
    Pawn pawnW6;
    Pawn pawnW7;
    Pawn pawnW8;
    Rook rookW1;
    Knight knightW1;
    Bishop bishopW1;
    Queen queenW;
    King kingW;
    Bishop bishopW2;
    Knight knightW2;
    Rook rookW2;


    private Piece[][] layout = new Piece[8][8];

    public Layout() {

        //We create a layout so we know were our pieces are

        //Last row
        this.rookB1 = new Rook(0,0,"Black","Black Rook*","|RB*|");
        this.knightB1 = new Knight(1,0,"Black","Black Knight*","|NB*|");
        this.bishopB1 = new Bishop(2,0,"Black","Black Bishop*","|BB*|");
        this.queenB = new Queen(3,0,"Black","Black Queen","|QB |");
        this.kingB = new King(4,0,"Black","Black King","|KB |");
        this.bishopB2 = new Bishop(5,0,"Black", "Black Bishop","|BB+|");
        this.knightB2 = new Knight(6,0,"Black","Black Knight","|NB+|" );
        this.rookB2 = new Rook(7,0,"Black","Black Rook","|RB+|");
        layout[0][0] = rookB1;
        layout[0][1] = knightB1;
        layout[0][2] = bishopB1;
        layout[0][3] = queenB;
        layout[0][4] = kingB;
        layout[0][5] = bishopB2;
        layout[0][6] = knightB2;
        layout[0][7] = rookB2;
        //7th row
        this.pawnB1 = new Pawn(0,1,"Black","Black Pawn 1","|PB1|");
        this.pawnB2 = new Pawn(1,1,"Black","Black Pawn 2","|PB2|");
        this.pawnB3 = new Pawn(2,1,"Black","Black Pawn 3","|PB3|");
        this.pawnB4 = new Pawn(3,1,"Black","Black Pawn 4","|PB4|");
        this.pawnB5 = new Pawn(4,1,"Black","Black Pawn 5","|PB5|");
        this.pawnB6 = new Pawn(5,1,"Black","Black Pawn 6","|PB6|");
        this.pawnB7 = new Pawn(6,1,"Black","Black Pawn 7","|PB7|");
        this.pawnB8 = new Pawn(7,1,"Black","Black Pawn 8","|PB8|");
        layout[1][0] =  pawnB1;
        layout[1][1] =  pawnB2;
        layout[1][2] =  pawnB3;
        layout[1][3] =  pawnB4;
        layout[1][4] =  pawnB5;
        layout[1][5] =  pawnB6;
        layout[1][6] =  pawnB7;
        layout[1][7] =  pawnB8;
        //Second row
        this.pawnW1 = new Pawn(0,6,"White","White Pawn 1","|PW1|");
        this.pawnW2 = new Pawn(1,6,"White","White Pawn 2","|PW2|");
        this.pawnW3 = new Pawn(2,6,"White","White Pawn 3","|PW3|");
        this.pawnW4 = new Pawn(3,6,"White","White Pawn 4","|PW4|");
        this.pawnW5 = new Pawn(4,6,"White","White Pawn 5","|PW5|");
        this.pawnW6 = new Pawn(5,6,"White","White Pawn 6","|PW6|");
        this.pawnW7 = new Pawn(6,6,"White","White Pawn 7","|PW7|");
        this.pawnW8 = new Pawn(7,6,"White","White Pawn 8","|PW8|");
        layout[6][0] =  pawnW1;
        layout[6][1] =  pawnW2;
        layout[6][2] =  pawnW3;
        layout[6][3] =  pawnW4;
        layout[6][4] =  pawnW5;
        layout[6][5] =  pawnW6;
        layout[6][6] =  pawnW7;
        layout[6][7] =  pawnW8;
        //First row
        this.rookW1 = new Rook(0,7,"White","White Rook*","|RW*|");
        this.knightW1 = new Knight(1,7,"White","White Knight*","|NW*|");
        this.bishopW1 = new Bishop(2,7,"White","White Bishop*","|BW*|");
        this.queenW = new Queen(3,7,"White","White Queen*","|QW |");
        this.kingW = new King(4,7,"White","White King*","|KW |");
        this.bishopW2 = new Bishop(5,7,"White","White Bishop+","|BW+|");
        this.knightW2 = new Knight(6,7,"White","White Knight+","|NW+|");
        this.rookW2 = new Rook(7,7,"White","White Rook+","|RW+|");
        layout[7][0] = rookW1;
        layout[7][1] = knightW1;
        layout[7][2] = bishopW1;
        layout[7][3] = queenW;
        layout[7][4] = kingW;
        layout[7][5] = bishopW2;
        layout[7][6] = knightW2;
        layout[7][7] = rookW2;
        for (int i = 0; i < layout.length; i ++) {
            for (int j = 0; j < layout.length; j++){
                if(layout[i][j] == null) layout[i][j] = new Empty(i, j, "null","Empty","|---|");
            }
        }
    }

    public Piece[][] getLayout() {
        return layout;
    }

    public Piece[][] getLayoutCopy(){
        Piece[][] layoutCopy = new Piece[8][8];
        for (int y = 0; y < 8; y++){
            for (int x = 0; x < 8; x++){
                layoutCopy[y][x] = layout[y][x].copy();
            }
        }
        return layoutCopy;
    }

    @Override
    public String toString() {
        StringBuilder statement = new StringBuilder();
        for (Piece[] pieces : layout) {
            for (int j = 0; j < layout.length; j++) {
                statement.append(pieces[j].getCode());
            }
            statement.append("\n");
        }
        return statement.toString();
    }
}
