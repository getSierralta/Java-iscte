package chess;

public class Position {
    // We made a class of Position
    private final int x;
    private final int y;

    public Position(int x, int y){
        this.x = x;
        this.y = y;
    }

    public int getY(){return y;}
    public int getX(){return x;}

    private char convertsPosToChar(int x){
        char[] abc={'A','B','C','D','E','F','G','H'};
        return abc[x];
    }

    @Override
    public String toString(){
        return "("+convertsPosToChar(getX())+","+(getY())+")";
    }
}
