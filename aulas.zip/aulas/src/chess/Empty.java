package chess;

public class Empty extends Piece{

    public Empty(int pos_x, int pos_y, String color, String name, String code) {
        super(pos_x, pos_y, color, name, code);
    }
    @Override
    public Piece copy() {
        Empty pieceCopy = new Empty(getPos().getX(),getPos().getY(),getColor(),getName(),getCode());
        return pieceCopy;
    }

    @Override
    public Position[] getMovements(){
        return new Position[0];
    }
}
