package aula8.calculator2;

import aula6.calculator.Calculator;

public class ScientificCalculator extends Calculator {

    private String[] historic;

    public ScientificCalculator(){
        historic = new String[1];
        historic[0] = "\nHistoric of the calculator: ";
    }

    public double power(double a, int power){
        double result = a;
        for (int i = 1; i < power; i++){
            result = result*a;
        }
        addToHistoric("Power: "+a+" to the "+power+" power = "+result);
        return result;
    }
    public double squareRoot(double a){
        double result = Math.sqrt(a);
        addToHistoric("The squared root of: "+a+" is "+result);
        return result;
    }
    public double remainder(double a, double b){
        double result = a%b;
        addToHistoric("Reminder: "+a+" / "+b+" = "+result);
        return result;
    }
    public double positiveQuadraticFormula(double a, double b,double c){
        double first = -b;
        double second = b*b-4*a*c;
        double third = 2*a;
        double result = (first + Math.sqrt(second))/third;
        addToHistoric("Positive quadratic formula: ("+first+" + √"+second+") / "+third+" = "+result);
        return result;
    }
    public double negativeQuadraticFormula(double a, double b,double c){
        double first = -b;
        double second = b*b-4*a*c;
        double third = 2*a;
        double result = (first - Math.sqrt(second))/third;
        addToHistoric("Negative quadratic formula: ("+first+" - √"+second+") / "+third+" = "+result);
        return result;
    }
    private String[] replaceHistoric(String[] copy){
        this.historic = new String[copy.length];
        for (int i = 0; i< this.historic.length; i++){
            this.historic[i] = copy[i];
        }
        return this.historic;
    }
    public void addToHistoric(String a){
        String[] copy = new String[historic.length+1];
        int i;
        for (i = 0; i < this.historic.length; i++){
            copy[i] = historic[i];
        }
        copy[i] = a;
        replaceHistoric(copy);
    }
    public void printHistoric(){

        for (int i = 0; i < historic.length; i++){
            System.out.println(historic[i]+"\n");
        }
        System.out.println("********************** End Historic **********************");
    }
    public void printHistoric(int a){
        if(a < historic.length){
            System.out.println("\nLast "+a+" lines of the calculator's historic: \n");
            int i = historic.length - a ;
            for (; i < historic.length; i++){
                System.out.println(historic[i]+"\n");
            }
            System.out.println("********************** End Historic **********************");
        }else {
            System.out.println("\nError the calculator haven't made "+a+" operations yet!\n");
            System.out.println("Here you have the full historic instead: ");
            printHistoric();
        }

    }
}
