package aula8.calculator2;

public class Main {
    public static void main (String[] args){
        //Crie uma classe calculadora. Esta classe deve ser abstrata e implementar as operações
        //básicas (soma, subtração, divisão e multiplicação).  Utilizando o conceito de herança
        //crie uma classe chamada calculadora científica que implementa os seguintes cálculos:
        //raiz quadrada e a potência. Dica : utilize a classe Math do pacote java.lang.
        ScientificCalculator a = new ScientificCalculator();
        System.out.println(a.sum(5,5)+"\n");
        System.out.println(a.subtraction(5,5)+"\n");
        System.out.println(a.division(5,5)+"\n");
        System.out.println(a.power(5,5)+"\n");
        System.out.println(a.remainder(5,3)+"\n");
        System.out.println(a.positiveQuadraticFormula(0.1,-2.5,2.5)+"\n");
        System.out.println(a.negativeQuadraticFormula(0.1,-2.5,2.5)+"\n");
        a.printHistoric();
        a.printHistoric(10);
    }


}
