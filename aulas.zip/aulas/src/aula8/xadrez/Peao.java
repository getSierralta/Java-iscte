package aula8.xadrez;

public class Peao extends PecaXadrez {
    public Peao(int pos_x, int pos_y, boolean white){
        super(pos_x,pos_y,white);
    }

    @Override
    public Posicao[] movimentosPossiveis() {
        if (isWhite()) {
            if (getPos().getY() < 1) {
                return new Posicao[0];
            } else if (getPos().getY() == 6) {
                return new Posicao[]{
                        new Posicao(getPos().getX(), 5),
                        new Posicao(getPos().getY(), 4)
                };
            } else {
                return new Posicao[]{
                        new Posicao(getPos().getX(), getPos().getY() - 1)
                };
            }

        } else {///peça preta
            if (getPos().getY() == 7) {
                return new Posicao[0];
            } else if (getPos().getY() == 1) {
                return new Posicao[]{
                        new Posicao(getPos().getX(), 2),
                        new Posicao(getPos().getY(), 3)
                };
            } else {
                return new Posicao[]{
                        new Posicao(getPos().getX(), getPos().getY() + 1)
                };
            }


        }


    }}
