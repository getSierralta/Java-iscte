package aula8.xadrez;

public class Posicao {
    private int x;
    private int y;

    public Posicao(int x, int y){
        this.x=x;
        this.y=x;
    }

    public int getY(){return y;}
    public int getX(){return x;}

    private char convertsPosToChar(int x){
        char[] abc={'A','B','C','D','E','F','G','H'};
        return abc[x];
    }

    @Override
    public String toString(){
        return "("+convertsPosToChar(getX())+","+(8-getY())+")";
    }
}
