package aula8.xadrez;

public class main {
    public static void main(String[] args) {
        Cavalo cavalo = new Cavalo(3, 4, true);
        Peao peao = new Peao(1, 1, false);
        Peao peao2 = new Peao(4, 2, true);

        System.out.println(cavalo);
        System.out.println(peao);
        System.out.println(peao2);
    }

}
