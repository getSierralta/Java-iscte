package aula8.xadrez;

public abstract class PecaXadrez {
    private Posicao pos;
    private boolean white;

    public PecaXadrez(int pos_x, int pos_y, boolean white){
        this.pos=new Posicao(pos_x,pos_y);
        this.white=white;
    }

    public Posicao getPos(){
        return pos;
    }

    public boolean isWhite(){
        return white;
    }

    public abstract Posicao[] movimentosPossiveis();

    @Override
    public String toString(){
        String retorno= "Esta peça tem os os seguintes movimentos possíveis: ";
        for(Posicao posicao:movimentosPossiveis()){
            retorno += posicao+",";
        }
        return retorno;
    }



}
