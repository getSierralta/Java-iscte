package aula8.shapes;

public class Main {
    public static void main (String[] args){
        //f. Elabore um programa de teste onde é declarado um array, de dimensão 5, do
        //tipo Forma . Nesse array, devem ser guardadas instâncias de Rectangulo ,
        //Circulo e Quadrado .
        //g. Depois, implemente um ciclo que percorra o array evocando, relativamente a
        //cada um dos objectos guardados, os métodos calcularArea e calcularPerimetro
        //imprima a informação para o ecrâ.



    }

}
