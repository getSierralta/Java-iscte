package aula8.shapes;

public class Square extends Rectagle2 {
    //e. Crie, como subclasse de Rectangulo , uma classe de nome Quadrado cujas
    //instâncias são caracterizadas por terem os atributos lado e altura com o
    //mesmo valor.

    public Square(float side) {
        super(side, side);
    }

}
