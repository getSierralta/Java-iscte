package aula8.shapes;

public abstract class Shape {
    //Implemente uma classe abstracta de nome Forma onde são declarados dois métodos
    //abstractos: float calcularArea(); e float cacularPerimetro();
    public abstract float getArea();
    public abstract float getPerimeter();
}
