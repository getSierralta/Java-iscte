package aula8.bankAccount;

public abstract class BankAccount {
    //senha, número, saldo
    private String password;
    private String number;
    private double balance = 0;

    public BankAccount(String password) {
        this.password = password;
        this.number = createNumber();
    }

    private String createNumber() {
        String number = "PT50 0002";
        for (int i = 0; i < 17; i++){
            number += (int) (Math.random()*10);
        }
        return number;
    }

    public String getNumber() {
        return number;
    }

    public double getBalance() {
        return balance;
    }
    public void setBalance(boolean inOrOut, double amount) {

        if (inOrOut){
            balance += amount;
        }else {
            balance -= amount;
        }
    }
    //c. Nesta mesma classe, crie o método alteraSenha, que recebe uma senha por
    //parâmetro e deve confirmar a senha anterior (via teclado), e somente se a
    //senha anterior estiver correta a senha recebida por parâmetro deve ser
    //atribuída.
    public void setPassword(String newPassword, String oldPassword) {
        if (oldPassword == password){
            this.password = newPassword;
            System.out.println("Password change succesfully!");
        }else {
            System.out.println("Incorrect password");
        }

    }

    //i. Levanta(double valor)
    public abstract void withdraw(double amount);
    //ii. deposita(double valor)
    public abstract void deposit(double amount);
    //iii. tiraExtrato()
    public abstract void getInformation();
}
