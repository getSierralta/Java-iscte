package aula8.bankAccount;

public class Main {
    public static void main (String[] args){
        //Implemente a hierarquia de classes ContaBancaria (superclasse), ContaCorrente (com
        //senha, número, saldo e quantidade de transações realizadas) e ContaPoupanca (com
        //senha, número, saldo e taxa de rendimento).
        //a. Quando uma ContaBancaria for criada, informe a senha da conta por
        //parâmetro.
        //b. Na classe ContaBancaria, crie os seguintes métodos abstratos:
        //i. Levanta(double valor)
        //ii. deposita(double valor)
        //iii. tiraExtrato()
        //c. Nesta mesma classe, crie o método alteraSenha, que recebe uma senha por
        //parâmetro e deve confirmar a senha anterior (via teclado), e somente se a
        //senha anterior estiver correta a senha recebida por parâmetro deve ser
        //atribuída.
        //d. Implemente os métodos abstratos nas classes ContaCorrente e
        //ContaPoupanca.
        //e. Crie os métodos de acesso ( getters ) para os atributos de ContaCorrente e
        //ContaPoupanca.

        SaveAccount save = new SaveAccount("123456789",0.15);
        ChekingAccount check = new ChekingAccount("987654321");
        save.withdraw(100);
        check.withdraw(100);
        save.deposit(500);
        check.deposit(1600);
        save.getInformation();
        check.getInformation();
    }


}
