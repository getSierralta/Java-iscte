package aula8.bankAccount;

public class SaveAccount extends BankAccount{

    private double rateOfReturn;

    public SaveAccount(String password, double rateOfReturn) {
        super(password);
        this.rateOfReturn = rateOfReturn;
    }

    public double getRateOfReturn() {
        return rateOfReturn;
    }

    public void setRateOfReturn(int rateOfReturn) {
        this.rateOfReturn = rateOfReturn;
    }

    @Override
    public void withdraw(double amount) {
        if ( super.getBalance() - amount > 0){
            super.setBalance(false,amount);
        }else {
            System.out.println("Error, insufficient balance.");
        }

    }

    @Override
    public void deposit(double amount) {
        super.setBalance(true, amount);
        System.out.println(amount+" deposit int the account "+super.getNumber()+" succesfully!");

    }

    @Override
    public void getInformation() {
        String s = "Account: " + super.getNumber()+"."
                +"\nBalance: "+ super.getBalance()+"."
                +"\nRate of Return: "+this.rateOfReturn+".";
        System.out.println(s);
    }
}
