package aula8.bankAccount;

public class ChekingAccount extends BankAccount {

    private int movements;

    public ChekingAccount(String password) {
        super(password);
    }

    public int getMovements() {
        return movements;
    }


    @Override
    public void withdraw(double amount) {
        movements++;
        if ( super.getBalance() - amount > 0){
            super.setBalance(false,amount);
        }else {
            System.out.println("Error, insufficient balance.");
        }

    }

    @Override
    public void deposit(double amount) {
        movements++;
        super.setBalance(true, amount);
        System.out.println(amount+" deposit int the account "+super.getNumber()+" succesfully!");

    }

    @Override
    public void getInformation() {
        String s = "Account " + super.getNumber()+"."
                +"\nBalance "+ super.getBalance()+"."
                +"\nMovements "+this.movements+".";
        System.out.println(s);
    }
}
