package aula7.game;

public class Main {

    public static void main(String[] args) {
        //Pretende-se escrever um programa para registar as estatísticas de jogadores de futebol.
        //Teste criando um jogador de campo e um guarda-redes e use as funções próprias de cada classe
        //para atribuir a cada jogador (desde que seja possível): 2 golos marcados, 3 golos sofridos, 4 passes
        //feitos e 5 passes recebidos.
        //Sobreponha o método toString em ambas as classes para melhor visualizar os resultados do teste.

        JogadorDeCampo uno = new JogadorDeCampo("Pedro",1);
        JogadorDeCampo dos = new JogadorDeCampo("Juancito",2);
        GuardaRedes cuatro = new GuardaRedes("Carlos", 4);
        uno.passeFeito();
        dos.passeRecebido();
        dos.passeFeito();
        cuatro.registro(true);
        uno.passeRecebido();
        dos.passeFeito();
        uno.passeRecebido();
        cuatro.registro(false);
        uno.passeRecebido();
        uno.registro();
        uno.passeRecebido();
        cuatro.registro(true);
        uno.passeRecebido();
        dos.registro();
        dos.registro();
        cuatro.registro(false);
        cuatro.registro(true);
        uno.getPasses();
        dos.getPasses();
        System.out.println(cuatro.inspetor());
        System.out.println(uno.inspetor());
        System.out.println(dos.inspetor());
        System.out.println(uno);
        System.out.println(dos);
        System.out.println(cuatro);
    }
}
