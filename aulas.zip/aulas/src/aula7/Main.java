package aula7;

import aula7.empresa.Diretor;
import aula7.empresa.Empregado;
import aula7.empresa.Empresa;
import aula7.empresa.Gerente;

public class Main {

    public static void main(String[] args) {



    }
}
