package aula7.empresa;

public class Diretor extends Empregado{

	private Empresa empresa;

	public Diretor(String nome, Empresa empresa) {
		super(nome);
		this.empresa = empresa;
	}
	public Empresa getEmpresa(){
		return empresa;
	}

	@Override
	public double getSalario() {
		return (super.getSalario() * 2) + (getEmpresa().getLucro() * 0.01);
	}

	@Override
	public String toString() {
		return "Empregado{ " +
				"nome ='" + getNome() + '\'' +
				", salario =" + getSalario() +
				'}';
	}
}
