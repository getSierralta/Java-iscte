package aula7.empresa;

public class Gerente extends Empregado{
	private  boolean cumpriuObjetivos = false;
	public Gerente(String nome) {
		super(nome);
	}
	public void setCumpriuObjetivos(boolean cumpriu){
		this.cumpriuObjetivos = cumpriu;
	}

	@Override
	public double getSalario() {
		if (cumpriuObjetivos){
			return super.getSalario() + 200;
		}
		return super.getSalario();
	}

	@Override
	public String toString() {
		return "Diretor{ " +
				"nome ='" + super.getNome() + '\'' +
				", salario =" + this.getSalario() +
				'}';
	}
}
