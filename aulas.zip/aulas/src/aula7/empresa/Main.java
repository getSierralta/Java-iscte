package aula7.empresa;

public class Main {

    public static void main(String[] args) {
        Empresa empresa = new Empresa("XPTO");
        empresa.setLucro(30000);
        Empregado diretor = new Diretor("Daniel",empresa);
        Empregado empregado = new Empregado("José");
        Empregado empregado1 = new Empregado("José Maria");
        Empregado empregado2 = new Empregado("Maria José");
        Gerente empregado3 = new Gerente("Joao");
        Gerente empregado4 = new Gerente("Joana");
        System.out.println(empregado);
        System.out.println(empresa);
        empresa.addEmpregado(empregado);
        empresa.addEmpregado(empregado1);
        empresa.addEmpregado(empregado2);
        empresa.addEmpregado(empregado3);
        empregado4.setCumpriuObjetivos(true);
        empresa.addEmpregado(empregado4);
        empregado4.setCumpriuObjetivos(true);
        System.out.println(empresa.getSalarioTotal());
        System.out.println(diretor);



    }
}
