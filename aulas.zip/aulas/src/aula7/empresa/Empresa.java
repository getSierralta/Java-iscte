package aula7.empresa;

import java.util.Arrays;

public class Empresa {
	private  String nome; 
	private Empregado[] listaEmpregado = new Empregado[0];
	private double lucro;


	public Empresa(String nome) {
		this.nome = nome;
	}
	public  String getNome(){
		return this.nome;
	}
	public void setLucro(double lucro) {
		this.lucro = lucro;
	}
	public double getLucro(){
		return this.lucro;
	}
	public double getSalarioTotal(){
		double soma = 0;
		for (Empregado empregado: listaEmpregado) {
			soma += empregado.getSalario();
		}
		return soma;
	}
	public void addEmpregado(Empregado empregado){
		// if empregado.equals()
		Empregado[] novaLista = new Empregado[listaEmpregado.length + 1];
		for (int i = 0; i < listaEmpregado.length; i++) {
			novaLista[i] = listaEmpregado[i];
		}
		novaLista[listaEmpregado.length] = empregado;
		this.listaEmpregado = novaLista;
	}
	@Override
	public String toString() {
		return "Empresa{" +
				"nome = '" + nome + '\'' +
				", listaEmpregado = " + Arrays.toString(listaEmpregado) +
				", lucro = " + lucro +
				'}';
	}
}
