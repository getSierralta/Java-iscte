package aula5;

import aula6.Person;

public class Main {

    public static void main(String[] args) {
        System.out.println("Numeros naturais até 39: ");
        int[] nat = Exercicios5.naturals(39);
        Exercicios5.printVetor(nat);
        char[] vetChar = {'a','b','c','a'};
        System.out.println("Vetor: ");
        Exercicios5.printVetor(vetChar);
        System.out.println("Contagem de 'a' no vetor == "+Exercicios5.contar('a',vetChar));
        char[] vetChar2 = {'a','b','c','a', 'f','1'};
        System.out.println("Vetor de caracteres: ");
        Exercicios5.printVetor(vetChar2);
        char[] subVet = Exercicios5.subArray(2,4,vetChar2);
        System.out.println("Entre 2 e 4: ");
        Exercicios5.printVetor(subVet);

        int[] v = new int[5];
        Exercicios5.vectorNumerosNaturais(v);
        int[] v1 = new int[50];
        Exercicios5.vectorNumerosNaturaisIntervalo(101,150,v1);
        int[] v2 = Exercicios5.copiarVector(v,9);
        System.out.println(Exercicios5.verificarNumero(v,9));
        System.out.println(Exercicios5.numeroOcorrencias(v,5));
        int[] v3 = Exercicios5.subVetor(v,2,5);
        int[] v4 = Exercicios5.metadeVetor(v,true);
        int[] v5 = Exercicios5.merge(v2,v3);
        int[] v6 = Exercicios5.copiarVectorInvert(v);
        int[] v7 = Exercicios5.doubleVetor(v);
        int[] v8 = Exercicios5.copiarVectorInvertDouble(v);
        int[] v9 = Exercicios5.copiarVetorNaoMetade(v);
        int[] v10 = Exercicios5.fibonacciVetor(10);
        Exercicios5.printVetor(v10);
    }
}
